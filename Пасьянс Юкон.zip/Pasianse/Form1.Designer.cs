﻿namespace Pasianse
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.AceOut4 = new System.Windows.Forms.Panel();
            this.AceOut3 = new System.Windows.Forms.Panel();
            this.AceOut2 = new System.Windows.Forms.Panel();
            this.AceOut1 = new System.Windows.Forms.Panel();
            this.stack1Pane = new System.Windows.Forms.Panel();
            this.stack2Pane = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.newGame = new System.Windows.Forms.ToolStripMenuItem();
            this.Restart = new System.Windows.Forms.ToolStripMenuItem();
            this.Settings = new System.Windows.Forms.ToolStripMenuItem();
            this.Background = new System.Windows.Forms.ToolStripMenuItem();
            this.green1 = new System.Windows.Forms.ToolStripMenuItem();
            this.green2 = new System.Windows.Forms.ToolStripMenuItem();
            this.wood1 = new System.Windows.Forms.ToolStripMenuItem();
            this.wood2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.колода1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.перекладыватьПоКликуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AllowPutOnClick = new System.Windows.Forms.ToolStripMenuItem();
            this.нетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Rules = new System.Windows.Forms.ToolStripMenuItem();
            this.tip = new System.Windows.Forms.ToolStripMenuItem();
            this.tipanswer = new System.Windows.Forms.ToolStripMenuItem();
            this.stack3Pane = new System.Windows.Forms.Panel();
            this.stack4Pane = new System.Windows.Forms.Panel();
            this.stack5Pane = new System.Windows.Forms.Panel();
            this.stack6Pane = new System.Windows.Forms.Panel();
            this.stack7Pane = new System.Windows.Forms.Panel();
            this.stackPanel = new System.Windows.Forms.Panel();
            this.rule = new System.Windows.Forms.RichTextBox();
            this.CloseButton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // AceOut4
            // 
            this.AceOut4.BackColor = System.Drawing.Color.DarkGreen;
            this.AceOut4.BackgroundImage = global::Pasianse.Properties.Resources.ace;
            this.AceOut4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AceOut4.Location = new System.Drawing.Point(741, 36);
            this.AceOut4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AceOut4.Name = "AceOut4";
            this.AceOut4.Size = new System.Drawing.Size(114, 159);
            this.AceOut4.TabIndex = 1;
            this.AceOut4.Visible = false;
            // 
            // AceOut3
            // 
            this.AceOut3.BackColor = System.Drawing.Color.DarkGreen;
            this.AceOut3.BackgroundImage = global::Pasianse.Properties.Resources.ace;
            this.AceOut3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AceOut3.Location = new System.Drawing.Point(619, 36);
            this.AceOut3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AceOut3.Name = "AceOut3";
            this.AceOut3.Size = new System.Drawing.Size(114, 159);
            this.AceOut3.TabIndex = 2;
            this.AceOut3.Visible = false;
            // 
            // AceOut2
            // 
            this.AceOut2.BackColor = System.Drawing.Color.DarkGreen;
            this.AceOut2.BackgroundImage = global::Pasianse.Properties.Resources.ace;
            this.AceOut2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AceOut2.Location = new System.Drawing.Point(498, 36);
            this.AceOut2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AceOut2.Name = "AceOut2";
            this.AceOut2.Size = new System.Drawing.Size(114, 159);
            this.AceOut2.TabIndex = 2;
            this.AceOut2.Visible = false;
            // 
            // AceOut1
            // 
            this.AceOut1.BackColor = System.Drawing.Color.DarkGreen;
            this.AceOut1.BackgroundImage = global::Pasianse.Properties.Resources.ace;
            this.AceOut1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AceOut1.Location = new System.Drawing.Point(377, 36);
            this.AceOut1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AceOut1.Name = "AceOut1";
            this.AceOut1.Size = new System.Drawing.Size(114, 159);
            this.AceOut1.TabIndex = 2;
            this.AceOut1.Visible = false;
            // 
            // stack1Pane
            // 
            this.stack1Pane.AllowDrop = true;
            this.stack1Pane.AutoSize = true;
            this.stack1Pane.BackColor = System.Drawing.Color.DarkGreen;
            this.stack1Pane.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stack1Pane.Location = new System.Drawing.Point(14, 203);
            this.stack1Pane.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stack1Pane.Name = "stack1Pane";
            this.stack1Pane.Size = new System.Drawing.Size(114, 159);
            this.stack1Pane.TabIndex = 3;
            this.stack1Pane.Visible = false;
            // 
            // stack2Pane
            // 
            this.stack2Pane.AllowDrop = true;
            this.stack2Pane.AutoSize = true;
            this.stack2Pane.BackColor = System.Drawing.Color.DarkGreen;
            this.stack2Pane.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stack2Pane.Location = new System.Drawing.Point(135, 203);
            this.stack2Pane.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stack2Pane.Name = "stack2Pane";
            this.stack2Pane.Size = new System.Drawing.Size(115, 159);
            this.stack2Pane.TabIndex = 2;
            this.stack2Pane.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = global::Pasianse.Properties.Resources._1;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGame,
            this.Restart,
            this.Settings,
            this.Rules,
            this.tip,
            this.tipanswer});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(864, 30);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // newGame
            // 
            this.newGame.BackColor = System.Drawing.SystemColors.Control;
            this.newGame.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.newGame.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.newGame.Name = "newGame";
            this.newGame.Size = new System.Drawing.Size(103, 24);
            this.newGame.Text = "Новая игра";
            this.newGame.Click += new System.EventHandler(this.NewGameButtonClick);
            // 
            // Restart
            // 
            this.Restart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Restart.Name = "Restart";
            this.Restart.Size = new System.Drawing.Size(126, 24);
            this.Restart.Text = "Начать заново";
            this.Restart.Visible = false;
            this.Restart.Click += new System.EventHandler(this.Restart_Click);
            // 
            // Settings
            // 
            this.Settings.BackColor = System.Drawing.SystemColors.Control;
            this.Settings.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Settings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Background,
            this.toolStripMenuItem3,
            this.перекладыватьПоКликуToolStripMenuItem});
            this.Settings.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Settings.Name = "Settings";
            this.Settings.Size = new System.Drawing.Size(98, 24);
            this.Settings.Text = "Настройки";
            // 
            // Background
            // 
            this.Background.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.green1,
            this.green2,
            this.wood1,
            this.wood2});
            this.Background.Name = "Background";
            this.Background.Size = new System.Drawing.Size(264, 26);
            this.Background.Text = "Фон";
            // 
            // green1
            // 
            this.green1.Checked = true;
            this.green1.CheckOnClick = true;
            this.green1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.green1.Name = "green1";
            this.green1.Size = new System.Drawing.Size(142, 26);
            this.green1.Text = "green 1";
            this.green1.Click += new System.EventHandler(this.green1_Click);
            // 
            // green2
            // 
            this.green2.CheckOnClick = true;
            this.green2.Name = "green2";
            this.green2.Size = new System.Drawing.Size(142, 26);
            this.green2.Text = "green 2";
            this.green2.Click += new System.EventHandler(this.green2_Click);
            // 
            // wood1
            // 
            this.wood1.CheckOnClick = true;
            this.wood1.Name = "wood1";
            this.wood1.Size = new System.Drawing.Size(142, 26);
            this.wood1.Text = "wood 1";
            this.wood1.Click += new System.EventHandler(this.wood1_Click);
            // 
            // wood2
            // 
            this.wood2.CheckOnClick = true;
            this.wood2.Name = "wood2";
            this.wood2.Size = new System.Drawing.Size(142, 26);
            this.wood2.Text = "wood 2";
            this.wood2.Click += new System.EventHandler(this.wood2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.колода1ToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(264, 26);
            this.toolStripMenuItem3.Text = "Карты";
            // 
            // колода1ToolStripMenuItem
            // 
            this.колода1ToolStripMenuItem.Checked = true;
            this.колода1ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.колода1ToolStripMenuItem.Name = "колода1ToolStripMenuItem";
            this.колода1ToolStripMenuItem.Size = new System.Drawing.Size(153, 26);
            this.колода1ToolStripMenuItem.Text = "колода 1";
            // 
            // перекладыватьПоКликуToolStripMenuItem
            // 
            this.перекладыватьПоКликуToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AllowPutOnClick,
            this.нетToolStripMenuItem});
            this.перекладыватьПоКликуToolStripMenuItem.Name = "перекладыватьПоКликуToolStripMenuItem";
            this.перекладыватьПоКликуToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.перекладыватьПоКликуToolStripMenuItem.Text = "Перекладывать по клику";
            // 
            // AllowPutOnClick
            // 
            this.AllowPutOnClick.Checked = true;
            this.AllowPutOnClick.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AllowPutOnClick.Name = "AllowPutOnClick";
            this.AllowPutOnClick.Size = new System.Drawing.Size(115, 26);
            this.AllowPutOnClick.Text = "да";
            // 
            // нетToolStripMenuItem
            // 
            this.нетToolStripMenuItem.CheckOnClick = true;
            this.нетToolStripMenuItem.Name = "нетToolStripMenuItem";
            this.нетToolStripMenuItem.Size = new System.Drawing.Size(115, 26);
            this.нетToolStripMenuItem.Text = "нет";
            // 
            // Rules
            // 
            this.Rules.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Rules.Name = "Rules";
            this.Rules.Size = new System.Drawing.Size(84, 24);
            this.Rules.Text = "Правила";
            this.Rules.Click += new System.EventHandler(this.Rules_Click);
            // 
            // tip
            // 
            this.tip.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tip.Name = "tip";
            this.tip.Size = new System.Drawing.Size(119, 24);
            this.tip.Text = "Есть ли ходы?";
            this.tip.Visible = false;
            this.tip.Click += new System.EventHandler(this.tip_Click);
            // 
            // tipanswer
            // 
            this.tipanswer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tipanswer.Name = "tipanswer";
            this.tipanswer.Size = new System.Drawing.Size(27, 24);
            this.tipanswer.Text = " ";
            // 
            // stack3Pane
            // 
            this.stack3Pane.AllowDrop = true;
            this.stack3Pane.AutoSize = true;
            this.stack3Pane.BackColor = System.Drawing.Color.DarkGreen;
            this.stack3Pane.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stack3Pane.Location = new System.Drawing.Point(256, 203);
            this.stack3Pane.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stack3Pane.Name = "stack3Pane";
            this.stack3Pane.Size = new System.Drawing.Size(118, 159);
            this.stack3Pane.TabIndex = 2;
            this.stack3Pane.Visible = false;
            // 
            // stack4Pane
            // 
            this.stack4Pane.AllowDrop = true;
            this.stack4Pane.AutoSize = true;
            this.stack4Pane.BackColor = System.Drawing.Color.DarkGreen;
            this.stack4Pane.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stack4Pane.Location = new System.Drawing.Point(377, 203);
            this.stack4Pane.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stack4Pane.Name = "stack4Pane";
            this.stack4Pane.Size = new System.Drawing.Size(114, 159);
            this.stack4Pane.TabIndex = 2;
            this.stack4Pane.Visible = false;
            // 
            // stack5Pane
            // 
            this.stack5Pane.AllowDrop = true;
            this.stack5Pane.AutoSize = true;
            this.stack5Pane.BackColor = System.Drawing.Color.DarkGreen;
            this.stack5Pane.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stack5Pane.Location = new System.Drawing.Point(498, 203);
            this.stack5Pane.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stack5Pane.Name = "stack5Pane";
            this.stack5Pane.Size = new System.Drawing.Size(114, 159);
            this.stack5Pane.TabIndex = 2;
            this.stack5Pane.Visible = false;
            // 
            // stack6Pane
            // 
            this.stack6Pane.AllowDrop = true;
            this.stack6Pane.AutoSize = true;
            this.stack6Pane.BackColor = System.Drawing.Color.DarkGreen;
            this.stack6Pane.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stack6Pane.Location = new System.Drawing.Point(619, 203);
            this.stack6Pane.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stack6Pane.Name = "stack6Pane";
            this.stack6Pane.Size = new System.Drawing.Size(114, 159);
            this.stack6Pane.TabIndex = 2;
            this.stack6Pane.Visible = false;
            // 
            // stack7Pane
            // 
            this.stack7Pane.AllowDrop = true;
            this.stack7Pane.AutoSize = true;
            this.stack7Pane.BackColor = System.Drawing.Color.DarkGreen;
            this.stack7Pane.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stack7Pane.Location = new System.Drawing.Point(741, 203);
            this.stack7Pane.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stack7Pane.Name = "stack7Pane";
            this.stack7Pane.Size = new System.Drawing.Size(114, 159);
            this.stack7Pane.TabIndex = 2;
            this.stack7Pane.Visible = false;
            // 
            // stackPanel
            // 
            this.stackPanel.BackColor = System.Drawing.Color.SaddleBrown;
            this.stackPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.stackPanel.Location = new System.Drawing.Point(14, 36);
            this.stackPanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stackPanel.Name = "stackPanel";
            this.stackPanel.Size = new System.Drawing.Size(114, 159);
            this.stackPanel.TabIndex = 4;
            this.stackPanel.Visible = false;
            // 
            // rule
            // 
            this.rule.Font = new System.Drawing.Font("Sylfaen", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rule.Location = new System.Drawing.Point(95, 110);
            this.rule.Name = "rule";
            this.rule.ReadOnly = true;
            this.rule.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rule.Size = new System.Drawing.Size(694, 431);
            this.rule.TabIndex = 5;
            this.rule.Text = resources.GetString("rule.Text");
            this.rule.Visible = false;
            // 
            // CloseButton
            // 
            this.CloseButton.Location = new System.Drawing.Point(639, 501);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(94, 29);
            this.CloseButton.TabIndex = 6;
            this.CloseButton.Text = "Закрыть";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Visible = false;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::Pasianse.Properties.Resources._1;
            this.ClientSize = new System.Drawing.Size(864, 876);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.rule);
            this.Controls.Add(this.stackPanel);
            this.Controls.Add(this.stack7Pane);
            this.Controls.Add(this.stack6Pane);
            this.Controls.Add(this.stack5Pane);
            this.Controls.Add(this.stack4Pane);
            this.Controls.Add(this.stack3Pane);
            this.Controls.Add(this.stack2Pane);
            this.Controls.Add(this.stack1Pane);
            this.Controls.Add(this.AceOut1);
            this.Controls.Add(this.AceOut2);
            this.Controls.Add(this.AceOut3);
            this.Controls.Add(this.AceOut4);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Юкон";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Panel AceOut4;
        private Panel AceOut3;
        private Panel AceOut2;
        private Panel AceOut1;
        private Panel stack1Pane;
        private Panel stack2Pane;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem newGame;
        private Panel stack3Pane;
        private Panel stack4Pane;
        private Panel stack5Pane;
        private Panel stack6Pane;
        private Panel stack7Pane;
        private Panel stackPanel;
        private ToolStripMenuItem Settings;
        private ToolStripMenuItem Background;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem green1;
        private ToolStripMenuItem green2;
        private ToolStripMenuItem Restart;
        private ToolStripMenuItem перекладыватьПоКликуToolStripMenuItem;
        private ToolStripMenuItem AllowPutOnClick;
        private ToolStripMenuItem нетToolStripMenuItem;
        private ToolStripMenuItem wood1;
        private ToolStripMenuItem wood2;
        private ToolStripMenuItem колода1ToolStripMenuItem;
        private ToolStripMenuItem Rules;
        private RichTextBox rule;
        private Button CloseButton;
        private ToolStripMenuItem tip;
        private ToolStripMenuItem tipanswer;
    }
}